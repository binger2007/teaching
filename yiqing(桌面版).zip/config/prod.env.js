"use strict";
module.exports = {
  NODE_ENV: '"production"',
  API_ROOT: '"http://api.howeaver.cn/public/cmsv3/"'
};

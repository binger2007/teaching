<template>
  <div class="hello">temp</div>
</template>

<script>
export default {
  name: "temp",
  data() {
    return {
      msg: "Welcome to Your Vue.js App"
    };
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>

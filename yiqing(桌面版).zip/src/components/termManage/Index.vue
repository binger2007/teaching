<template>
  <div class="hello">期班管理</div>
</template>

<script>
export default {
  name: "termManage",
  data() {
    return {
      msg: "Welcome to Your Vue.js App"
    };
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>

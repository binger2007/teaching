<template>
  <div class="hello">开发中。。。在会员中心自己添加数据</div>
</template>

<script>
export default {
  name: "member",
  data() {
    return {
      msg: "Welcome to Your Vue.js App"
    };
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped></style>

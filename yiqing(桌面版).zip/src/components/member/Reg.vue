<template>
  <div class="hello">开发中。。。会员注册页面</div>
</template>

<script>
export default {
  name: "reg",
  data() {
    return {
      msg: "Welcome to Your Vue.js App"
    };
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped></style>

<?php

namespace app\cms\model;

use think\Model;

class User extends Model
{
    
}

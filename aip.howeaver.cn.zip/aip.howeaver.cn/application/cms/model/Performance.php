<?php

namespace app\cms\model;

use think\Model;

class Performance extends Model
{
    protected $table = 'performance';
}

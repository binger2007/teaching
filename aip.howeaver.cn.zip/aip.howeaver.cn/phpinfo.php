<?php
 phpinfo();
?><?php
 phpinfo();
?><?php
 phpinfo();
?>